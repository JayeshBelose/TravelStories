import { useEffect, useState, useRef, useCallback } from "react";
import { toast } from "react-toastify";
import {
    Search,
    Trash,
    X,
    ChevronLeft,
    ChevronRight,
    Shield,
    User,
} from "lucide-react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { ui } from "@/styles/uiPrimitives";
import ErrorState from "@/components/common/ErrorState";
import ConfirmToast from "@/components/common/ConfirmToast";
import ItineraryOverlay from "@/components/itinerary/ItineraryOverlay";
import UserItineraryListOverlay from "@/components/itinerary/UserItineraryListOverlay";
import {
    deleteUserByAdminService,
    getAdminUsersService,
} from "@/services/adminService";
import UserTableRow from "@/components/admin/UserTableRow";

export default function UserManagement() {
    const [users, setUsers] = useState([]);
    const [search, setSearch] = useState("");
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const [page, setPage] = useState(0);
    const [totalPages, setTotalPages] = useState(0);
    const [selectedUser, setSelectedUser] = useState(null);
    const [selectedItinerary, setSelectedItinerary] = useState(null);
    const [loadingUsers, setLoadingUsers] = useState(true);
    const [usersError, setUsersError] = useState(null);
    const [deletingUserId, setDeletingUserId] = useState(null);

    const requestIdRef = useRef(0);

    useEffect(() => {
        let isMounted = true;
        const requestId = ++requestIdRef.current;

        const loadUsers = async () => {
            setLoadingUsers(true);
            setUsersError(null);

            try {
                const result = await getAdminUsersService({
                    page,
                    size: 10,
                    search: debouncedSearch,
                });

                if (!isMounted || requestId !== requestIdRef.current) {
                    return;
                }

                if (!result.success) {
                    setUsersError(
                        result.message ||
                            "We couldn't load the users. Please try again.",
                    );
                    setUsers([]);
                    setTotalPages(0);
                    return;
                }

                setUsers(result.data.content);
                setTotalPages(result.data.totalPages);
            } catch (error) {
                if (!isMounted || requestId !== requestIdRef.current) {
                    return;
                }

                console.error("Failed to load admin users:", error);

                setUsersError(
                    error.message ||
                        "We couldn't load the users. Please try again.",
                );

                setUsers([]);
                setTotalPages(0);
            } finally {
                if (isMounted && requestId === requestIdRef.current) {
                    setLoadingUsers(false);
                }
            }
        };

        loadUsers();

        return () => {
            isMounted = false;
        };
    }, [page, debouncedSearch]);

    const fetchUsers = useCallback(async () => {
        setLoadingUsers(true);
        setUsersError(null);

        try {
            const result = await getAdminUsersService({
                page,
                size: 10,
                search: debouncedSearch,
            });

            if (!result.success) {
                console.error("Failed to load admin users:", result.message);

                setUsersError(
                    result.message ||
                        "We couldn't load the users. Please try again.",
                );

                setUsers([]);
                setTotalPages(0);
                return;
            }

            setUsers(result.data.content);
            setTotalPages(result.data.totalPages);
        } catch (error) {
            console.error("Failed to load admin users:", error);

            setUsersError(
                error.message ||
                    "We couldn't load the users. Please try again.",
            );

            setUsers([]);
            setTotalPages(0);
        } finally {
            setLoadingUsers(false);
        }
    }, [page, debouncedSearch]);

    useEffect(() => {
        fetchUsers();
    }, [fetchUsers]);

    const handleUsersRetry = useCallback(() => {
        fetchUsers();
    }, [fetchUsers]);

    const handleDelete = useCallback(async (userId) => {
        setDeletingUserId(userId);

        try {
            const result = await deleteUserByAdminService({
                userId,
            });

            if (result.success) {
                setUsers((prev) =>
                    prev.filter((user) => user.userId !== userId),
                );

                toast.success("User deleted successfully.");
            } else {
                toast.error(result.message);
            }
        } catch (error) {
            console.error("Failed to delete user:", error);
            toast.error("Unable to delete user. Please try again.");
        } finally {
            setDeletingUserId(null);
        }
    }, []);

    const confirmDelete = useCallback(
        (userId) => {
            toast(
                ({ closeToast }) => (
                    <ConfirmToast
                        message="Are you sure you want to delete this user? This action cannot be undone."
                        confirmLabel="Delete"
                        onConfirm={() => {
                            handleDelete(userId);
                            closeToast();
                        }}
                        onCancel={closeToast}
                    />
                ),
                { autoClose: false },
            );
        },
        [handleDelete],
    );

    useEffect(() => {
        const delay = setTimeout(() => {
            setDebouncedSearch(search);
            setPage(0);
        }, 400);
        return () => clearTimeout(delay);
    }, [search]);

    return (
        <div>
            {/* Header */}
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 font-primary tracking-tight mb-1">
                    User Management
                </h1>
                <p className="text-sm text-gray-400">
                    Manage all platform users
                </p>
            </div>

            {/* Search */}
            <div
                className={`${ui.searchContainer} w-full sm:max-w-md flex items-center gap-2.5 mb-5`}
            >
                <Search size={15} className="text-gray-400 flex-shrink-0" />
                <input
                    type="text"
                    aria-label="Search users by username or email"
                    placeholder="Search by username or email…"
                    className="w-full bg-transparent outline-none text-sm text-gray-700 placeholder:text-gray-300"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                {search && (
                    <button
                        type="button"
                        onClick={() => setSearch("")}
                        aria-label="Clear user search"
                        className="text-gray-300 hover:text-gray-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-gray-400 rounded cursor-pointer"
                    >
                        <X size={14} aria-hidden="true" />
                    </button>
                )}
            </div>

            {/* Table */}
            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[900px] text-sm">
                        <thead>
                            <tr className="border-b border-gray-100 text-left">
                                {[
                                    "User",
                                    "Email",
                                    "Role",
                                    "Joined",
                                    "Followers",
                                    "Following",
                                    "Actions",
                                ].map((h) => (
                                    <th
                                        key={h}
                                        className={`px-5 py-3 text-[11px] font-semibold uppercase tracking-widest text-gray-400 ${
                                            h === "Actions" ? "text-right" : ""
                                        }`}
                                        scope="col"
                                    >
                                        {h}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody
                            aria-busy={loadingUsers}
                            aria-label="Loading users"
                        >
                            {loadingUsers &&
                                Array.from({ length: 6 }).map((_, i) => (
                                    <tr
                                        key={i}
                                        className="border-b border-gray-50"
                                    >
                                        <td className="px-5 py-3">
                                            <div className="flex items-center gap-3">
                                                <Skeleton className="w-8 h-8 rounded-full flex-shrink-0" />
                                                <Skeleton className="h-3.5 w-24" />
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <Skeleton className="h-3.5 w-36" />
                                        </td>
                                        <td className="px-4 py-3">
                                            <Skeleton className="h-5 w-16 rounded-full" />
                                        </td>
                                        <td className="px-4 py-3">
                                            <Skeleton className="h-3.5 w-20" />
                                        </td>
                                        <td className="px-4 py-3 text-center">
                                            <Skeleton className="h-3.5 w-8 mx-auto" />
                                        </td>
                                        <td className="px-4 py-3 text-center">
                                            <Skeleton className="h-3.5 w-8 mx-auto" />
                                        </td>
                                        <td className="px-4 py-3 text-right">
                                            <Skeleton className="h-7 w-7 rounded-full ml-auto" />
                                        </td>
                                    </tr>
                                ))}

                            {!loadingUsers && usersError && (
                                <tr>
                                    <td colSpan={7}>
                                        <ErrorState
                                            compact
                                            title="Unable to load users"
                                            message={usersError}
                                            onRetry={handleUsersRetry}
                                        />
                                    </td>
                                </tr>
                            )}

                            {!loadingUsers &&
                                !usersError &&
                                users.map((user) => (
                                    <UserTableRow
                                        key={user.userId}
                                        user={user}
                                        setSelectedUser={setSelectedUser}
                                        confirmDelete={confirmDelete}
                                        deletingUserId={deletingUserId}
                                    />
                                ))}
                        </tbody>
                    </table>
                </div>

                {!loadingUsers && !usersError && users.length === 0 && (
                    <div className="py-16 text-center text-sm text-gray-400">
                        No users found.
                    </div>
                )}
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-center gap-3 mt-5">
                <button
                    aria-label="Go to previous page"
                    disabled={page === 0 || loadingUsers || !!usersError}
                    onClick={() => setPage((p) => p - 1)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:border-gray-400 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                >
                    <ChevronLeft size={15} />
                </button>
                <span className="text-sm text-gray-500">
                    Page{" "}
                    <span className="font-semibold text-gray-900">
                        {page + 1}
                    </span>{" "}
                    of {totalPages}
                </span>
                <button
                    aria-label="Go to next page"
                    disabled={
                        page >= totalPages - 1 || loadingUsers || !!usersError
                    }
                    onClick={() => setPage((p) => p + 1)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:border-gray-400 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                >
                    <ChevronRight size={15} />
                </button>
            </div>

            <UserItineraryListOverlay
                open={!!selectedUser}
                user={selectedUser}
                onClose={() => setSelectedUser(null)}
                onSelectItinerary={(itinerary) =>
                    setSelectedItinerary(itinerary)
                }
            />

            <ItineraryOverlay
                open={!!selectedItinerary}
                itinerary={selectedItinerary}
                onClose={() => setSelectedItinerary(null)}
            />
        </div>
    );
}
