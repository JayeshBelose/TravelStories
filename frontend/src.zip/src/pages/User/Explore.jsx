import { useState, useMemo, useEffect, useRef, useCallback } from "react";
import {
    Filter,
    Search,
    X,
    Compass,
    ChevronLeft,
    ChevronRight,
} from "lucide-react";
import ItineraryCard from "@/components/itinerary/ItineraryCard";
import ItineraryOverlay from "@/components/itinerary/ItineraryOverlay";
import { Skeleton } from "@/components/ui/skeleton";
import { ui } from "@/styles/uiPrimitives";
import ErrorState from "@/components/common/ErrorState";
import {
    getItinerariesService,
    getItineraryTypesService,
} from "@/services/itineraryService";

const SORT_OPTIONS = [
    { value: "recent", label: "Most Recent" },
    { value: "likes", label: "Most Liked" },
    { value: "saves", label: "Most Saved" },
    { value: "random", label: "No Filter" },
];

export default function Explore() {
    const [selectedItinerary, setSelectedItinerary] = useState(null);
    const [itineraries, setItineraries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [search, setSearch] = useState("");
    const [appliedSearch, setAppliedSearch] = useState("");
    const [sortFilter, setSortFilter] = useState("random");
    const [typeFilter, setTypeFilter] = useState(null); // null = "all"
    const [openSort, setOpenSort] = useState(false);
    const [openType, setOpenType] = useState(false);
    const [totalPages, setTotalPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(1);
    const [itineraryTypes, setItineraryTypes] = useState([]);

    const requestRef = useRef(0);
    const sortRef = useRef(null);
    const typeRef = useRef(null);

    // Close dropdowns on outside click
    useEffect(() => {
        const handler = (e) => {
            if (sortRef.current && !sortRef.current.contains(e.target))
                setOpenSort(false);
            if (typeRef.current && !typeRef.current.contains(e.target))
                setOpenType(false);
        };
        document.addEventListener("mousedown", handler);
        return () => document.removeEventListener("mousedown", handler);
    }, []);

    // Fetch itinerary types from Service
    useEffect(() => {
        const fetchTypes = async () => {
            const currentRequestId = ++requestRef.current;

            try {
                const result = await getItineraryTypesService();

                if (currentRequestId !== requestRef.current) return;

                if (result.success) {
                    setItineraryTypes(result.data);
                }
            } catch (error) {
                console.error(error);
            }
        };

        fetchTypes();
    }, []);

    const fetchItineraries = useCallback(async () => {
        const currentRequestId = ++requestRef.current;

        setLoading(true);
        setError(null);

        try {
            const result = await getItinerariesService({
                search: appliedSearch,
                type: typeFilter ?? undefined,
                sort: sortFilter,
                page: currentPage - 1,
                size: 9,
            });

            if (currentRequestId !== requestRef.current) return;

            if (result.success) {
                setItineraries(result.data.content);
                setTotalPages(result.data.totalPages);
            } else {
                setItineraries([]);
                setTotalPages(1);
                setError(result.message);
            }
        } catch (error) {
            if (currentRequestId !== requestRef.current) return;

            setItineraries([]);
            setTotalPages(1);
            setError("Failed to load itineraries.");
        } finally {
            if (currentRequestId === requestRef.current) {
                setLoading(false);
            }
        }
    }, [appliedSearch, sortFilter, typeFilter, currentPage]);

    useEffect(() => {
        const delay = setTimeout(fetchItineraries, 400);

        return () => clearTimeout(delay);
    }, [fetchItineraries]);

    useEffect(() => {
        setCurrentPage(1);
    }, [sortFilter, typeFilter]);

    const sortLabel = useMemo(
        () =>
            SORT_OPTIONS.find((o) => o.value === sortFilter)?.label ??
            "No Filter",
        [sortFilter],
    );

    const typeLabel = useMemo(
        () =>
            typeFilter === null
                ? "All Types"
                : (itineraryTypes.find((t) => t.name === typeFilter)?.name ??
                  "All Types"),
        [typeFilter, itineraryTypes],
    );

    const sortActive = sortFilter !== "random";
    const typeActive = typeFilter !== null;
    const searchActive = appliedSearch.trim().length > 0;

    // Page numbers with ellipsis
    const pageNumbers = useMemo(() => {
        if (totalPages <= 7)
            return Array.from({ length: totalPages }, (_, i) => i + 1);
        const pages = new Set([
            1,
            totalPages,
            currentPage,
            currentPage - 1,
            currentPage + 1,
        ]);
        return [...pages]
            .filter((p) => p >= 1 && p <= totalPages)
            .sort((a, b) => a - b);
    }, [totalPages, currentPage]);

    return (
        <div className="min-h-screen">
            {/* Header */}
            <div className="mb-8">
                <div className="flex items-start justify-between gap-6 mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 font-primary tracking-tight mb-1">
                            Explore
                        </h1>
                        <p className="text-sm text-gray-400">
                            Discover trips shared by the community
                        </p>
                    </div>
                </div>

                {/* Search + Filters row */}
                <div className="flex flex-wrap gap-3">
                    {/* Search */}
                    <div
                        className={`${ui.searchContainer} flex-1 min-w-56 flex items-center gap-2.5`}
                    >
                        <input
                            type="text"
                            placeholder="Search by title or place…"
                            aria-label="Search itineraries"
                            className="w-full bg-transparent outline-none text-sm text-gray-700 placeholder:text-gray-300"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                    setCurrentPage(1);
                                    setAppliedSearch(search);
                                }
                            }}
                        />

                        {search && (
                            <button
                                onClick={() => {
                                    setSearch("");
                                    setAppliedSearch("");
                                }}
                                className="text-gray-300 hover:text-gray-500 transition-colors cursor-pointer"
                                aria-label="Clear search"
                            >
                                <X size={14} />
                            </button>
                        )}

                        <button
                            onClick={() => {
                                setCurrentPage(1);
                                setAppliedSearch(search);
                            }}
                            disabled={!search.trim()}
                            className="flex items-center justify-center w-7 h-4 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                            aria-label="Search"
                        >
                            <Search size={15} />
                        </button>
                    </div>

                    {/* Sort dropdown */}
                    <div ref={sortRef} className="relative">
                        <button
                            onClick={() => {
                                setOpenSort((v) => !v);
                                setOpenType(false);
                            }}
                            aria-expanded={openSort}
                            aria-haspopup="menu"
                            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium shadow-sm transition-colors cursor-pointer
                                ${
                                    sortActive
                                        ? "bg-gray-900 text-white border-gray-900"
                                        : "bg-white text-gray-600 border-gray-200 hover:border-gray-400"
                                }`}
                        >
                            <Filter size={13} />
                            {sortLabel}
                        </button>
                        {openSort && (
                            <div className="absolute right-0 mt-2 w-44 bg-white rounded-xl border border-gray-100 shadow-lg z-20 overflow-hidden py-1">
                                {SORT_OPTIONS.map((opt) => (
                                    <button
                                        key={opt.value}
                                        onClick={() => {
                                            setSortFilter(opt.value);
                                            setOpenSort(false);
                                        }}
                                        className={`block w-full text-left px-4 py-2 text-sm transition-colors cursor-pointer
                                            ${
                                                sortFilter === opt.value
                                                    ? "bg-gray-50 text-gray-900 font-medium"
                                                    : "text-gray-600 hover:bg-gray-50"
                                            }`}
                                    >
                                        {opt.label}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Type dropdown */}
                    <div ref={typeRef} className="relative">
                        <button
                            onClick={() => {
                                setOpenType((v) => !v);
                                setOpenSort(false);
                            }}
                            aria-expanded={openType}
                            aria-haspopup="menu"
                            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium shadow-sm transition-colors cursor-pointer
                                ${
                                    typeActive
                                        ? "bg-gray-900 text-white border-gray-900"
                                        : "bg-white text-gray-600 border-gray-200 hover:border-gray-400"
                                }`}
                        >
                            <Filter size={13} />
                            {typeLabel}
                        </button>
                        {openType && (
                            <div className="absolute right-0 mt-2 w-44 bg-white rounded-xl border border-gray-100 shadow-lg z-20 overflow-hidden py-1 max-h-56 overflow-y-auto">
                                {/* "All Types" option */}
                                <button
                                    onClick={() => {
                                        setTypeFilter(null);
                                        setOpenType(false);
                                    }}
                                    className={`block w-full text-left px-4 py-2 text-sm transition-colors cursor-pointer
                                        ${
                                            typeFilter === null
                                                ? "bg-gray-50 text-gray-900 font-medium"
                                                : "text-gray-600 hover:bg-gray-50"
                                        }`}
                                >
                                    All Types
                                </button>

                                {itineraryTypes.map((type) => (
                                    <button
                                        key={type.typeId}
                                        onClick={() => {
                                            setTypeFilter(type.name);
                                            setOpenType(false);
                                        }}
                                        className={`block w-full text-left px-4 py-2 text-sm capitalize transition-colors cursor-pointer
                                            ${
                                                typeFilter === type.name
                                                    ? "bg-gray-50 text-gray-900 font-medium"
                                                    : "text-gray-600 hover:bg-gray-50"
                                            }`}
                                    >
                                        {type.name}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Active filter chips */}
                {(sortActive || typeActive || searchActive) && (
                    <div className="flex flex-wrap gap-2 mt-3">
                        {searchActive && (
                            <span className="inline-flex items-center gap-1.5 text-xs bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full">
                                "{appliedSearch}"
                                <button
                                    onClick={() => {
                                        setSearch("");
                                        setAppliedSearch("");
                                    }}
                                    className="hover:text-gray-900 cursor-pointer"
                                >
                                    <X size={11} />
                                </button>
                            </span>
                        )}
                        {sortActive && (
                            <span className="inline-flex items-center gap-1.5 text-xs bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full">
                                {sortLabel}
                                <button
                                    onClick={() => setSortFilter("random")}
                                    className="hover:text-gray-900 cursor-pointer"
                                >
                                    <X size={11} />
                                </button>
                            </span>
                        )}
                        {typeActive && (
                            <span className="inline-flex items-center gap-1.5 text-xs bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full capitalize">
                                {typeLabel}
                                <button
                                    onClick={() => setTypeFilter(null)}
                                    className="hover:text-gray-900 cursor-pointer"
                                >
                                    <X size={11} />
                                </button>
                            </span>
                        )}
                    </div>
                )}
            </div>

            {/* Loading / Error / Empty / Content */}
            {loading ? (
                <div
                    aria-busy="true"
                    aria-label="Loading itineraries"
                    className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
                >
                    {Array.from({ length: 6 }).map((_, i) => (
                        <div
                            key={i}
                            className="rounded-2xl overflow-hidden border border-gray-100 shadow-sm"
                        >
                            <Skeleton className="h-48 w-full rounded-none" />
                            <div className="p-4 space-y-2">
                                <Skeleton className="h-3.5 w-3/4" />
                                <Skeleton className="h-3 w-1/2" />
                                <Skeleton className="h-3 w-1/3" />
                            </div>
                        </div>
                    ))}
                </div>
            ) : error ? (
                <ErrorState
                    title="Unable to load itineraries"
                    message={error}
                    onRetry={fetchItineraries}
                />
            ) : itineraries.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-24 gap-4 text-gray-400">
                    <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center">
                        <Compass size={26} className="text-gray-300" />
                    </div>
                    <div className="text-center">
                        <p className="text-sm font-medium text-gray-600 mb-1">
                            No itineraries found
                        </p>
                        {appliedSearch && (
                            <p className="text-xs text-gray-400">
                                Nothing matched{" "}
                                <span className="font-semibold text-gray-600">
                                    "{appliedSearch}"
                                </span>
                            </p>
                        )}
                    </div>
                    <button
                        onClick={() => {
                            setSearch("");
                            setAppliedSearch("");
                            setSortFilter("random");
                            setTypeFilter(null);
                        }}
                        className="text-xs text-gray-500 underline underline-offset-2 hover:text-gray-800 transition-colors cursor-pointer"
                    >
                        Clear all filters
                    </button>
                </div>
            ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {itineraries.map((itinerary) => (
                        <ItineraryCard
                            key={itinerary.itineraryId}
                            itinerary={itinerary}
                            onClick={setSelectedItinerary}
                        />
                    ))}
                </div>
            )}

            {/* Pagination */}
            {!loading && !error && totalPages > 1 && (
                <div className="flex justify-center items-center gap-1.5 mt-12">
                    <button
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage((p) => p - 1)}
                        className="w-9 h-9 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:border-gray-400 hover:text-gray-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                    >
                        <ChevronLeft size={15} />
                    </button>

                    {pageNumbers.map((page, idx) => {
                        const prev = pageNumbers[idx - 1];
                        const showEllipsis = prev && page - prev > 1;
                        return (
                            <span
                                key={page}
                                className="flex items-center gap-1.5"
                            >
                                {showEllipsis && (
                                    <span className="text-gray-300 text-sm px-1">
                                        …
                                    </span>
                                )}
                                <button
                                    onClick={() => setCurrentPage(page)}
                                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors cursor-pointer
                                        ${
                                            currentPage === page
                                                ? "bg-gray-900 text-white"
                                                : "text-gray-500 hover:bg-gray-100 border border-gray-200 hover:border-gray-300"
                                        }`}
                                >
                                    {page}
                                </button>
                            </span>
                        );
                    })}

                    <button
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage((p) => p + 1)}
                        className="w-9 h-9 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:border-gray-400 hover:text-gray-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                    >
                        <ChevronRight size={15} />
                    </button>
                </div>
            )}

            <ItineraryOverlay
                itinerary={selectedItinerary}
                onClose={() => setSelectedItinerary(null)}
                allowRelatedItineraries={true}
            />
        </div>
    );
}
