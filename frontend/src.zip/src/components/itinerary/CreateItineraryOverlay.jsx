import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { itinerarySchema } from "@/schemas/itinerarySchemas";
import {
    X,
    Plus,
    Trash,
    Upload,
    Globe,
    Lock,
    MapPin,
    Users,
    ImageIcon,
    ChevronDown,
} from "lucide-react";
import { toast } from "react-toastify";
import { ui } from "@/styles/uiPrimitives";
import ErrorState from "@/components/common/ErrorState";
import DayCard from "@/components/itinerary/DayCard";
import {
    addMemberService,
    createItineraryService,
    getItineraryDetailsService,
    getItineraryTypesService,
    removeMemberService,
    updateItineraryService,
    uploadThumbnailService,
} from "@/services/itineraryService";
import {
    getFollowingService,
    getFollowersService,
} from "@/services/userService";
import {
    createDayService,
    deleteDayService,
    getItineraryDaysService,
    updateDayService,
} from "@/services/dayService";
import {
    createLocationService,
    deleteLocationService,
    getDayLocationsService,
    updateLocationService,
} from "@/services/locationService";
import {
    deleteLocationImageService,
    getLocationImagesService,
    uploadLocationImageService,
} from "@/services/imageService";

// Custom Tailwind CSS tags
function SectionLabel({ children }) {
    return <p className={`${ui.sectionLabel} mb-3`}>{children}</p>;
}

function FieldLabel({ children, required }) {
    return (
        <label className="block text-sm font-medium text-gray-700 mb-1.5">
            {children}
            {required && <span className="text-red-400 ml-0.5">*</span>}
        </label>
    );
}

export default function CreateItineraryOverlay({
    open,
    onClose,
    existingItinerary = null,
    onSaved,
}) {
    const user = useMemo(() => {
        try {
            return JSON.parse(sessionStorage.getItem("user"));
        } catch {
            return null;
        }
    }, []);

    // Allowing edit mode to both creator and Admin
    const isEditMode = !!existingItinerary || user?.role === "admin";

    const isCreator =
        existingItinerary?.createdBy === user?.username ||
        user?.role === "admin";

    const [itineraryId, setItineraryId] = useState(null);
    const [thumbnailFile, setThumbnailFile] = useState(null);
    const [thumbnailPreview, setThumbnailPreview] = useState(null);

    const [isPublic, setIsPublic] = useState(true);
    const [days, setDays] = useState([]);
    const [followingList, setFollowingList] = useState([]);
    const [followersList, setFollowersList] = useState([]);
    const [members, setMembers] = useState([]);
    const [memberSearch, setMemberSearch] = useState("");
    const [types, setTypes] = useState([]);
    const [saving, setSaving] = useState(false);

    const [loadingData, setLoadingData] = useState(open);
    const [loadError, setLoadError] = useState(null);
    const [loadAttempt, setLoadAttempt] = useState(0);

    const [deletedDays, setDeletedDays] = useState([]);
    const [deletedLocations, setDeletedLocations] = useState([]);
    const [deletedImages, setDeletedImages] = useState([]);

    const dialogRef = useRef(null);
    const previousFocusRef = useRef(null);

    const {
        register,
        handleSubmit,
        reset,
        watch,
        formState: { errors, isSubmitting },
    } = useForm({
        resolver: zodResolver(itinerarySchema),
        mode: "onChange",
        defaultValues: {
            title: "",
            place: "",
            type: "",
            startDate: "",
            endDate: "",
            description: "",
        },
    });

    useEffect(() => {
        if (!open) {
            return;
        }

        previousFocusRef.current = document.activeElement;

        const dialog = dialogRef.current;

        if (dialog) {
            dialog.focus();
        }

        const handleEscape = (event) => {
            if (event.key === "Escape" && !saving) {
                onClose();
            }
        };

        document.addEventListener("keydown", handleEscape);

        return () => {
            document.removeEventListener("keydown", handleEscape);

            if (
                previousFocusRef.current &&
                typeof previousFocusRef.current.focus === "function"
            ) {
                previousFocusRef.current.focus();
            }
        };
    }, [open, onClose, saving]);

    /*
     * Cleanup thumbnail preview URL whenever it changes or
     * when the component unmounts.
     */
    useEffect(() => {
        return () => {
            if (thumbnailPreview) {
                URL.revokeObjectURL(thumbnailPreview);
            }
        };
    }, [thumbnailPreview]);

    /*
     * Fetch itinerary data if in edit mode.
     */
    useEffect(() => {
        if (!open) return;

        let cancelled = false;

        const loadData = async () => {
            setLoadingData(true);
            setLoadError(null);

            try {
                const [typesResult, followingResult, followersResult] =
                    await Promise.all([
                        getItineraryTypesService(),
                        getFollowingService({
                            userId: user.userId,
                        }),
                        getFollowersService({
                            userId: user.userId,
                        }),
                    ]);

                if (cancelled) return;

                /*
                 * Itinerary types are required for the form.
                 * Without them, the user cannot reliably select the
                 * itinerary type.
                 */
                if (!typesResult.success) {
                    setLoadError({
                        title: "Unable to load itinerary types",
                        message:
                            typesResult.message ||
                            "We couldn't load the available itinerary types. Please try again.",
                    });

                    return;
                }

                setTypes(typesResult.data);

                /*
                 * Following users are optional.
                 * A failure here should not prevent the user from
                 * creating or editing the itinerary.
                 */
                if (followingResult.success) {
                    setFollowingList(followingResult.data);
                } else {
                    console.error(
                        "Failed to load following users:",
                        followingResult.message,
                    );
                    setFollowingList([]);
                }

                if (followersResult.success) {
                    setFollowersList(followersResult.data);
                } else {
                    console.error(
                        "Failed to load followers:",
                        followersResult.message,
                    );
                    setFollowersList([]);
                }

                /*
                 * Create mode does not require any additional API data.
                 */
                if (!isEditMode || !existingItinerary) {
                    resetForm();
                    return;
                }

                const id = existingItinerary.itineraryId;

                setItineraryId(id);

                /*
                 * Edit mode requires both the itinerary itself and
                 * its days before the form can be populated safely.
                 */
                const [itineraryResult, daysResult] = await Promise.all([
                    getItineraryDetailsService({
                        itineraryId: id,
                    }),
                    getItineraryDaysService({
                        itineraryId: id,
                    }),
                ]);

                if (cancelled) return;

                if (!itineraryResult.success) {
                    setLoadError({
                        title: "Unable to load itinerary",
                        message:
                            itineraryResult.message ||
                            "We couldn't load this itinerary. Please try again.",
                    });

                    return;
                }

                if (!daysResult.success) {
                    setLoadError({
                        title: "Unable to load itinerary days",
                        message:
                            daysResult.message ||
                            "We couldn't load the itinerary days. Please try again.",
                    });

                    return;
                }

                const itinerary = itineraryResult.data;

                reset({
                    title: itinerary.title || "",
                    place: itinerary.place || "",
                    type: itinerary.type || "",
                    startDate: itinerary.startDate || "",
                    endDate: itinerary.endDate || "",
                    description: itinerary.description || "",
                });
                setIsPublic(itinerary.public);
                setMembers(itinerary.members || []);

                /*
                 * Locations and images are secondary resources.
                 * Their failures should not prevent the main itinerary
                 * from being displayed/edited.
                 */
                const loadedDays = await Promise.all(
                    daysResult.data.map(async (day) => {
                        const locationsResult = await getDayLocationsService({
                            dayId: day.dayId,
                        });

                        if (cancelled) return null;

                        if (!locationsResult.success) {
                            console.error(
                                `Failed to load locations for day ${day.dayId}:`,
                                locationsResult.message,
                            );

                            return {
                                ...day,
                                locations: [],
                                locationsLoadError: true,
                            };
                        }

                        const loadedLocations = await Promise.all(
                            locationsResult.data.map(async (location) => {
                                const imagesResult =
                                    await getLocationImagesService({
                                        locationId: location.locationId,
                                    });

                                if (cancelled) return null;

                                if (!imagesResult.success) {
                                    console.error(
                                        `Failed to load images for location ${location.locationId}:`,
                                        imagesResult.message,
                                    );

                                    return {
                                        ...location,
                                        name: location.locationName || "",
                                        address: location.locationAddress || "",
                                        images: [],
                                        imagesLoadError: true,
                                    };
                                }

                                return {
                                    ...location,
                                    name: location.locationName || "",
                                    address: location.locationAddress || "",
                                    images: imagesResult.data.map((image) => ({
                                        ...image,
                                        isNew: false,
                                        file: null,
                                    })),
                                };
                            }),
                        );

                        if (cancelled) return null;

                        return {
                            ...day,
                            locations: loadedLocations.filter(Boolean),
                        };
                    }),
                );

                if (cancelled) return;

                setDays(loadedDays.filter(Boolean));
            } finally {
                if (!cancelled) {
                    setLoadingData(false);
                }
            }
        };

        loadData();

        return () => {
            cancelled = true;
        };
    }, [open, existingItinerary, loadAttempt]);

    useEffect(() => {
        return () => {
            days.forEach((day) => {
                day.locations?.forEach((location) => {
                    location.images?.forEach((image) => {
                        if (image.isNew && image.previewUrl) {
                            URL.revokeObjectURL(image.previewUrl);
                        }
                    });
                });
            });
        };
    }, []);

    const resetForm = () => {
        setItineraryId(null);
        reset({
            title: "",
            place: "",
            type: "",
            startDate: "",
            endDate: "",
            description: "",
        });
        setIsPublic(true);
        setDays([]);
        setMembers([]);
        setMemberSearch("");
        setThumbnailFile(null);

        /*
         * Revoke the currently active thumbnail preview before
         * clearing the state reference.
         */
        if (thumbnailPreview) {
            URL.revokeObjectURL(thumbnailPreview);
        }

        setThumbnailPreview(null);
        setDeletedDays([]);
        setDeletedLocations([]);
        setDeletedImages([]);
    };

    // Remove functions
    const removeDay = useCallback((index) => {
        setDays((prev) => {
            const day = prev[index];

            if (day?.dayId) {
                setDeletedDays((deleted) => [...deleted, day.dayId]);
            }

            return prev.filter((_, i) => i !== index);
        });
    }, []);

    const removeLocation = useCallback((dayIndex, locIndex) => {
        setDays((prev) => {
            const location = prev[dayIndex]?.locations?.[locIndex];

            if (location?.locationId) {
                setDeletedLocations((deleted) => [
                    ...deleted,
                    {
                        dayId: prev[dayIndex].dayId,
                        locationId: location.locationId,
                    },
                ]);
            }

            return prev.map((day, index) =>
                index === dayIndex
                    ? {
                          ...day,
                          locations: day.locations.filter(
                              (_, i) => i !== locIndex,
                          ),
                      }
                    : day,
            );
        });
    }, []);

    const removeImage = useCallback((dayIndex, locIndex, imgIndex) => {
        setDays((prev) =>
            prev.map((day, dIndex) => {
                if (dIndex !== dayIndex) return day;

                return {
                    ...day,
                    locations: day.locations.map((location, lIndex) => {
                        if (lIndex !== locIndex) return location;

                        const image = location.images[imgIndex];

                        if (!image.isNew && image.imageId) {
                            setDeletedImages((deleted) => [
                                ...deleted,
                                image.imageId,
                            ]);
                        }

                        if (image.isNew && image.previewUrl) {
                            URL.revokeObjectURL(image.previewUrl);
                        }

                        return {
                            ...location,
                            images: location.images.filter(
                                (_, i) => i !== imgIndex,
                            ),
                        };
                    }),
                };
            }),
        );
    }, []);

    const followerIds = useMemo(
        () => new Set(followersList.map((f) => f.userId)),
        [followersList],
    );

    const friendsList = useMemo(
        () => followingList.filter((user) => followerIds.has(user.userId)),
        [followingList, followerIds],
    );

    const memberIds = useMemo(
        () => new Set(members.map((m) => m.userId)),
        [members],
    );

    const filteredMembers = useMemo(() => {
        const search = memberSearch.trim().toLowerCase();

        if (!search) return [];

        return friendsList.filter(
            (user) =>
                user.username.toLowerCase().includes(search) &&
                !memberIds.has(user.userId),
        );
    }, [friendsList, memberIds, memberSearch]);

    const sortedTypes = useMemo(() => {
        return [...types].sort((a, b) =>
            a.name
                .trim()
                .toLowerCase()
                .localeCompare(b.name.trim().toLowerCase(), undefined, {
                    sensitivity: "base",
                }),
        );
    }, [types]);

    const thumbnailUrl = useMemo(() => {
        if (thumbnailPreview) return thumbnailPreview;

        if (!itineraryId) return null;

        return `${import.meta.env.VITE_API_BASE_URL}/itineraries/${itineraryId}/thumbnail`;
    }, [thumbnailPreview, itineraryId]);

    if (!open) return null;

    if (loadingData || loadError) {
        return (
            <div
                className="fixed inset-0 bg-black/50 backdrop-blur-sm flex justify-end z-50"
                onClick={onClose}
            >
                <div
                    ref={dialogRef}
                    tabIndex={-1}
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="create-itinerary-title"
                    className="bg-white w-full max-w-xl h-full flex flex-col shadow-2xl overflow-hidden"
                    onClick={(e) => e.stopPropagation()}
                >
                    <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 flex-shrink-0">
                        <h2
                            id="create-itinerary-title"
                            className="text-base font-semibold text-gray-900 font-primary"
                        >
                            {isEditMode ? "Edit Itinerary" : "New Itinerary"}
                        </h2>

                        <button
                            onClick={onClose}
                            disabled={saving || loadingData}
                            aria-label="Close"
                            className="w-8 h-8 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            <X size={16} />
                        </button>
                    </div>

                    <div className="flex-1 flex items-center justify-center">
                        {loadingData ? (
                            <div
                                className="flex flex-col items-center justify-center text-center px-6"
                                role="status"
                                aria-live="polite"
                            >
                                <div
                                    className="w-10 h-10 border-2 border-gray-200 border-t-gray-900 rounded-full animate-spin"
                                    aria-hidden="true"
                                />

                                <p className="mt-4 text-sm font-medium text-gray-700">
                                    {isEditMode
                                        ? "Loading itinerary..."
                                        : "Preparing itinerary form..."}
                                </p>
                            </div>
                        ) : (
                            <ErrorState
                                title={loadError.title}
                                message={loadError.message}
                                onRetry={() => {
                                    setLoadError(null);
                                    setLoadAttempt((prev) => prev + 1);
                                }}
                            />
                        )}
                    </div>
                </div>
            </div>
        );
    }

    const createOrUpdateItinerary = async (data) => {
        const itinerary = {
            title: data.title.trim(),
            place: data.place.trim(),
            type: data.type,
            startDate: data.startDate,
            endDate: data.endDate,
            description: data.description.trim(),
            public: isPublic,
        };

        if (saving) return;

        setSaving(true);

        try {
            let result;

            /*
             * Create or update the itinerary itself.
             */
            if (isEditMode && isCreator) {
                result = await updateItineraryService({
                    itineraryId,
                    itinerary,
                });
            } else {
                result = await createItineraryService({
                    userId: user.userId,
                    itinerary,
                });
            }

            if (!result.success) {
                toast.error(result.message);
                return;
            }

            const id = result.data.itineraryId;

            setItineraryId(id);

            /*
             * Delete resources that were removed from the editor.
             */
            await Promise.all([
                ...deletedImages.map((imageId) =>
                    deleteLocationImageService({
                        imageId,
                    }),
                ),

                ...deletedLocations.map(({ dayId, locationId }) =>
                    deleteLocationService({
                        dayId,
                        locationId,
                    }),
                ),

                ...deletedDays.map((dayId) =>
                    deleteDayService({
                        itineraryId: id,
                        dayId,
                    }),
                ),
            ]);

            /*
             * Upload the itinerary thumbnail if a new one was selected.
             */
            if (thumbnailFile) {
                const formData = new FormData();
                formData.append("file", thumbnailFile);

                const thumbnailResult = await uploadThumbnailService({
                    itineraryId: id,
                    formData,
                });

                if (!thumbnailResult.success) {
                    toast.error(thumbnailResult.message);
                    return;
                }
            }

            /*
             * Create/update days, locations and images.
             *
             * These operations remain sequential because later
             * operations depend on IDs created by earlier operations.
             */
            for (const day of days) {
                let dayId = day.dayId;

                /*
                 * Create or update day.
                 */
                if (!dayId) {
                    const dayResult = await createDayService({
                        itineraryId: id,
                        day: {
                            description: day.description,
                        },
                    });

                    if (!dayResult.success) {
                        toast.error(dayResult.message);
                        return;
                    }

                    dayId = dayResult.data.dayId;
                } else {
                    const dayResult = await updateDayService({
                        itineraryId: id,
                        dayId,
                        day: {
                            description: day.description,
                        },
                    });

                    if (!dayResult.success) {
                        toast.error(dayResult.message);
                        return;
                    }
                }

                /*
                 * Create/update locations belonging to this day.
                 */
                for (const location of day.locations || []) {
                    let locationId = location.locationId;

                    if (!locationId) {
                        const locationResult = await createLocationService({
                            dayId,
                            location: {
                                locationName: location.name,
                                locationAddress: location.address,
                            },
                        });

                        if (!locationResult.success) {
                            toast.error(locationResult.message);
                            return;
                        }

                        locationId = locationResult.data.locationId;
                    } else {
                        const locationResult = await updateLocationService({
                            dayId,
                            locationId,
                            location: {
                                locationName: location.name,
                                locationAddress: location.address,
                            },
                        });

                        if (!locationResult.success) {
                            toast.error(locationResult.message);
                            return;
                        }
                    }

                    /*
                     * Upload newly-added location images.
                     */
                    for (const image of location.images || []) {
                        if (!image.isNew || !image.file) continue;

                        const formData = new FormData();
                        formData.append("file", image.file);

                        const imageResult = await uploadLocationImageService({
                            locationId,
                            formData,
                        });

                        if (!imageResult.success) {
                            toast.error(imageResult.message);
                            return;
                        }
                    }
                }
            }

            /*
             * Synchronize itinerary members.
             */
            const existingMembers = existingItinerary?.members || [];

            await Promise.all([
                ...existingMembers
                    .filter(
                        (member) =>
                            !members.some(
                                (selected) => selected.userId === member.userId,
                            ),
                    )
                    .map((member) =>
                        removeMemberService({
                            itineraryId: id,
                            userId: member.userId,
                        }),
                    ),

                ...members
                    .filter(
                        (member) =>
                            !existingMembers.some(
                                (existing) => existing.userId === member.userId,
                            ),
                    )
                    .map((member) =>
                        addMemberService({
                            itineraryId: id,
                            userId: member.userId,
                        }),
                    ),
            ]);

            /*
             * All mutations succeeded.
             *
             * Only now notify the parent component.
             */
            onSaved?.(result.data);

            /*
             * Clear mutation tracking after successful save.
             */
            setDeletedDays([]);
            setDeletedLocations([]);
            setDeletedImages([]);

            toast.success(
                isEditMode ? "Itinerary updated!" : "Itinerary created!",
            );

            onClose();
        } catch (err) {
            console.error("Failed to save itinerary:", err);
            toast.error("Something went wrong. Please try again.");
        } finally {
            setSaving(false);
        }
    };

    return (
        <div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex justify-end z-50"
            onClick={onClose}
        >
            <div
                className="bg-white w-full max-w-xl h-full flex flex-col shadow-2xl overflow-hidden"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 flex-shrink-0">
                    <h2 className="text-base font-semibold text-gray-900 font-primary">
                        {isEditMode ? "Edit Itinerary" : "New Itinerary"}
                    </h2>

                    <button
                        onClick={onClose}
                        disabled={saving}
                        aria-label="Close"
                        className="w-8 h-8 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <X size={16} />
                    </button>
                </div>

                {/* Scrollable Body */}
                <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
                    {/* Thumbnail */}
                    <div className="bg-gray-50 border border-gray-100 rounded-2xl overflow-hidden">
                        {(thumbnailPreview ||
                            (isEditMode && existingItinerary)) && (
                            <div className="relative h-36 w-full">
                                <img
                                    src={thumbnailUrl}
                                    alt="Itinerary thumbnail"
                                    className="w-full h-full object-cover"
                                />

                                <div className="absolute inset-0 bg-black/20" />
                            </div>
                        )}

                        <label className="flex items-center gap-2 px-4 py-3 cursor-pointer hover:bg-gray-100 transition-colors">
                            <Upload size={14} className="text-gray-400" />

                            <span className="text-sm text-gray-500 truncate">
                                {thumbnailFile
                                    ? thumbnailFile.name
                                    : "Upload thumbnail"}
                            </span>

                            <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                disabled={saving}
                                onChange={(e) => {
                                    const file = e.target.files?.[0];

                                    if (!file) return;

                                    /*
                                     * Revoke the previous preview before
                                     * replacing it.
                                     */
                                    if (thumbnailPreview) {
                                        URL.revokeObjectURL(thumbnailPreview);
                                    }

                                    setThumbnailFile(file);
                                    setThumbnailPreview(
                                        URL.createObjectURL(file),
                                    );

                                    /*
                                     * Allows selecting the same file again.
                                     */
                                    e.target.value = "";
                                }}
                            />
                        </label>
                    </div>

                    {/* Itinerary Info */}
                    <div className="bg-white border border-gray-100 rounded-2xl p-5 space-y-4">
                        <SectionLabel>Basic Info</SectionLabel>

                        {/* Title */}
                        <div>
                            <FieldLabel required>Title</FieldLabel>

                            <input
                                type="text"
                                placeholder="e.g. Summer in Tokyo"
                                {...register("title")}
                                disabled={saving || isSubmitting}
                                aria-invalid={errors.title ? "true" : "false"}
                                aria-describedby={
                                    errors.title
                                        ? "itinerary-title-error"
                                        : undefined
                                }
                                className={`${ui.input} ${
                                    errors.title
                                        ? "border-red-300 focus:border-red-400 bg-red-50/30"
                                        : ""
                                }`}
                            />

                            {errors.title && (
                                <p
                                    id="itinerary-title-error"
                                    className="text-xs text-red-400 mt-1"
                                >
                                    {errors.title.message}
                                </p>
                            )}
                        </div>

                        {/* Place */}
                        <div>
                            <FieldLabel required>Place</FieldLabel>

                            <div className="relative">
                                <MapPin
                                    size={14}
                                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-300 pointer-events-none"
                                />

                                <input
                                    type="text"
                                    placeholder="City, Country"
                                    {...register("place")}
                                    disabled={saving || isSubmitting}
                                    aria-invalid={
                                        errors.place ? "true" : "false"
                                    }
                                    aria-describedby={
                                        errors.place
                                            ? "itinerary-place-error"
                                            : undefined
                                    }
                                    className={`${ui.input} pl-9 ${
                                        errors.place
                                            ? "border-red-300 focus:border-red-400 bg-red-50/30"
                                            : ""
                                    }`}
                                />
                            </div>

                            {errors.place && (
                                <p
                                    id="itinerary-place-error"
                                    className="text-xs text-red-400 mt-1"
                                >
                                    {errors.place.message}
                                </p>
                            )}
                        </div>

                        {/* Type */}
                        <div>
                            <FieldLabel required>Type</FieldLabel>

                            <div className="relative">
                                <select
                                    {...register("type")}
                                    disabled={saving || isSubmitting}
                                    aria-invalid={
                                        errors.type ? "true" : "false"
                                    }
                                    aria-describedby={
                                        errors.type
                                            ? "itinerary-type-error"
                                            : undefined
                                    }
                                    className={`${ui.select} appearance-none pr-8 ${
                                        errors.type
                                            ? "border-red-300 focus:border-red-400 bg-red-50/30"
                                            : ""
                                    }`}
                                >
                                    <option value="">Select a type</option>

                                    {sortedTypes.map((t) => (
                                        <option key={t.typeId} value={t.name}>
                                            {t.name}
                                        </option>
                                    ))}
                                </select>

                                <ChevronDown
                                    size={14}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300 pointer-events-none"
                                />
                            </div>

                            {errors.type && (
                                <p
                                    id="itinerary-type-error"
                                    className="text-xs text-red-400 mt-1"
                                >
                                    {errors.type.message}
                                </p>
                            )}
                        </div>

                        {/* Start and End Dates */}
                        <div>
                            <FieldLabel required>Start Date</FieldLabel>

                            <input
                                type="date"
                                {...register("startDate")}
                                disabled={saving || isSubmitting}
                                className={`${ui.input} ${
                                    errors.startDate
                                        ? "border-red-300 focus:border-red-400 bg-red-50/30"
                                        : ""
                                }`}
                            />

                            {errors.startDate && (
                                <p className="text-xs text-red-400 mt-1">
                                    {errors.startDate.message}
                                </p>
                            )}
                        </div>

                        <div>
                            <FieldLabel required>End Date</FieldLabel>

                            <input
                                type="date"
                                {...register("endDate")}
                                disabled={saving || isSubmitting}
                                className={`${ui.input} ${
                                    errors.endDate
                                        ? "border-red-300 focus:border-red-400 bg-red-50/30"
                                        : ""
                                }`}
                            />

                            {errors.endDate && (
                                <p className="text-xs text-red-400 mt-1">
                                    {errors.endDate.message}
                                </p>
                            )}
                        </div>

                        {/* Description */}
                        <div>
                            <FieldLabel>Description</FieldLabel>

                            <textarea
                                rows={3}
                                placeholder="What's this trip about?"
                                {...register("description")}
                                disabled={saving || isSubmitting}
                                maxLength={500}
                                className={`${ui.textarea} resize-none ${
                                    errors.description
                                        ? "border-red-300 focus:border-red-400 bg-red-50/30"
                                        : ""
                                }`}
                            />

                            {errors.description && (
                                <p className="text-xs text-red-400 mt-1">
                                    {errors.description.message}
                                </p>
                            )}

                            <p className="text-xs text-gray-300 mt-1 text-right">
                                {(watch("description") || "").length} / 500
                            </p>
                        </div>
                    </div>

                    {/* Members */}
                    <div className="bg-white border border-gray-100 rounded-2xl p-5">
                        <SectionLabel>Members</SectionLabel>

                        <div className="relative">
                            <Users
                                size={14}
                                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-300 pointer-events-none"
                            />

                            <input
                                placeholder="Search friends to add..."
                                value={memberSearch}
                                onChange={(e) =>
                                    setMemberSearch(e.target.value)
                                }
                                className={`${ui.input} pl-9`}
                                disabled={saving}
                            />
                        </div>

                        {filteredMembers.length > 0 && (
                            <div className="mt-2 border border-gray-100 rounded-xl overflow-hidden">
                                {filteredMembers.map((member) => (
                                    <button
                                        key={member.userId}
                                        type="button"
                                        onClick={() => {
                                            setMembers((prev) => [
                                                ...prev,
                                                member,
                                            ]);
                                            setMemberSearch("");
                                        }}
                                        disabled={saving}
                                        className="flex items-center gap-3 w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors cursor-pointer text-left disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        <div className="w-6 h-6 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                                            <img
                                                src={`${import.meta.env.VITE_API_BASE_URL}/users/${member.userId}/profilePicture`}
                                                alt={member.username}
                                                className="w-full h-full object-cover"
                                            />
                                        </div>

                                        {member.username}
                                    </button>
                                ))}
                            </div>
                        )}

                        {members.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-3">
                                {members.map((member) => (
                                    <span
                                        key={member.userId}
                                        className="inline-flex items-center gap-1.5 bg-gray-100 border border-gray-200 text-gray-700 text-xs font-medium px-2.5 py-1 rounded-full"
                                    >
                                        {member.username}

                                        <button
                                            type="button"
                                            onClick={() =>
                                                setMembers((prev) =>
                                                    prev.filter(
                                                        (m) =>
                                                            m.userId !==
                                                            member.userId,
                                                    ),
                                                )
                                            }
                                            disabled={saving}
                                            aria-label={`Remove ${member.username}`}
                                            className="text-gray-400 hover:text-gray-700 cursor-pointer disabled:cursor-not-allowed"
                                        >
                                            <X size={11} />
                                        </button>
                                    </span>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Days */}
                    <div>
                        <div className="flex items-center justify-between mb-3">
                            <SectionLabel>Itinerary Days</SectionLabel>

                            <button
                                type="button"
                                onClick={() =>
                                    setDays((prev) => [
                                        ...prev,
                                        {
                                            description: "",
                                            locations: [],
                                        },
                                    ])
                                }
                                disabled={saving}
                                className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-gray-900 bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                <Plus size={12} />
                                Add Day
                            </button>
                        </div>

                        <div className="space-y-3">
                            {days.map((day, dayIndex) => (
                                <DayCard
                                    key={day.dayId ?? `day-${dayIndex}`}
                                    day={day}
                                    dayIndex={dayIndex}
                                    saving={saving}
                                    removeDay={removeDay}
                                    removeLocation={removeLocation}
                                    removeImage={removeImage}
                                    setDays={setDays}
                                />
                            ))}
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="flex flex-wrap items-center justify-between gap-3 px-4 lg:px-6 py-4 border-t border-gray-100 flex-shrink-0 bg-white">
                    {/* Visibility toggle */}
                    <button
                        type="button"
                        onClick={() => setIsPublic(!isPublic)}
                        disabled={saving}
                        className={`inline-flex items-center gap-2 text-xs font-medium px-3 py-2 rounded-xl border transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed
                            ${
                                isPublic
                                    ? "bg-emerald-50 border-emerald-200 text-emerald-600 hover:bg-emerald-100"
                                    : "bg-gray-100 border-gray-200 text-gray-500 hover:bg-gray-200"
                            }`}
                    >
                        {isPublic ? (
                            <>
                                <Globe size={12} />
                                Public
                            </>
                        ) : (
                            <>
                                <Lock size={12} />
                                Private
                            </>
                        )}
                    </button>

                    <div className="flex items-center gap-2">
                        <button
                            type="button"
                            onClick={onClose}
                            disabled={saving}
                            className="px-4 py-2 text-sm text-gray-500 hover:text-gray-800 hover:bg-gray-100 rounded-xl transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSubmit(createOrUpdateItinerary)}
                            disabled={saving || isSubmitting}
                            aria-busy={saving || isSubmitting}
                            className="flex items-center gap-2 bg-gray-900 hover:bg-gray-700 text-white text-sm font-medium px-5 py-2.5 rounded-xl transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {saving
                                ? "Saving…"
                                : isEditMode
                                  ? "Update"
                                  : "Create"}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
